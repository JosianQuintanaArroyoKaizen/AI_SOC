"""
Serverless Dashboard API Lambda
Provides REST endpoints for threat dashboard
"""

import json
import boto3
import os
from decimal import Decimal

dynamodb = boto3.client('dynamodb')
TABLE_NAME = os.environ.get('TABLE_NAME', 'ai-soc-dev-state')

def calculate_priority_score(threat_score, source, event_type):
    """
    Calculate priority score matching alert-triage logic.
    Removes circular dependency on severity level.
    """
    import logging
    logger = logging.getLogger()
    
    # Debug: Log input values
    logger.info(f"[DEBUG] Input - threat_score: {threat_score} (type: {type(threat_score)}), source: {source}, event_type: {event_type}")
    
    # Convert threat_score to 0-100 range if it's in decimal format (0-1)
    if threat_score <= 1.0:
        base_score = threat_score * 100
    else:
        base_score = threat_score
    
    logger.info(f"[DEBUG] base_score after conversion: {base_score}")
    
    # Source trust multipliers
    source_weights = {
        "aws.guardduty": 1.2,
        "aws.securityhub": 1.15,
        "aws.cloudtrail": 1.0,
        "aws.config": 1.05,
    }
    
    # Critical event types
    critical_events = [
        "GuardDuty Finding",
        "UnauthorizedAccess",
        "Recon",
        "Trojan",
        "Backdoor",
        "Cryptomining",
        "RootCredentials",
        "IAMUser/AnomalousBehavior"
    ]
    
    # Apply source weight
    source_multiplier = source_weights.get(source, 1.0)
    adjusted_score = base_score * source_multiplier
    
    logger.info(f"[DEBUG] source_multiplier: {source_multiplier}, adjusted_score: {adjusted_score}")
    
    # Boost for critical event types
    if any(keyword in event_type for keyword in critical_events):
        adjusted_score *= 1.25
        logger.info(f"[DEBUG] Critical event boost applied, final adjusted_score: {adjusted_score}")
    
    final_score = min(100, max(0, adjusted_score))
    logger.info(f"[DEBUG] Final priority_score: {final_score}")
    
    return final_score

class DecimalEncoder(json.JSONEncoder):
    """Helper to convert Decimal to int/float for JSON"""
    def default(self, obj):
        if isinstance(obj, Decimal):
            return int(obj) if obj % 1 == 0 else float(obj)
        return super(DecimalEncoder, self).default(obj)

def deserialize_dynamodb_item(item):
    """Convert DynamoDB item format to regular Python dict"""
    if isinstance(item, dict):
        if 'S' in item:
            return item['S']
        elif 'N' in item:
            return float(item['N'])
        elif 'BOOL' in item:
            return item['BOOL']
        elif 'NULL' in item:
            return None
        elif 'M' in item:
            return {k: deserialize_dynamodb_item(v) for k, v in item['M'].items()}
        elif 'L' in item:
            return [deserialize_dynamodb_item(i) for i in item['L']]
    return item

def cors_headers():
    """CORS headers for browser access"""
    return {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET,OPTIONS'
    }

def response(status_code, body):
    """Standard API response"""
    return {
        'statusCode': status_code,
        'headers': cors_headers(),
        'body': json.dumps(body, cls=DecimalEncoder)
    }

def get_threats():
    """Get all threats from DynamoDB"""
    try:
        threats_by_severity = {'CRITICAL': [], 'HIGH': [], 'MEDIUM': [], 'LOW': [], 'UNKNOWN': []}
        last_evaluated_key = None
        max_items_to_scan = 300  # Reduced limit - scan fewer items for faster response

        # Paginate through results with limit
        items_scanned = 0
        while items_scanned < max_items_to_scan:
            scan_kwargs = {
                'TableName': TABLE_NAME,
                'Limit': min(100, max_items_to_scan - items_scanned)  # Fetch in batches of 100
            }
            if last_evaluated_key:
                scan_kwargs['ExclusiveStartKey'] = last_evaluated_key

            result = dynamodb.scan(**scan_kwargs)

            for item in result.get('Items', []):
                deserialized_item = {k: deserialize_dynamodb_item(v) for k, v in item.items()}
                ml_prediction = deserialized_item.get('ml_prediction', {})
                threat_score = float(ml_prediction.get('threat_score', 0))
                prediction_label = ml_prediction.get('prediction_label')
                model_version = ml_prediction.get('model_version')
                evaluated_at = ml_prediction.get('evaluated_at')
                raw_event = deserialized_item.get('raw_event', {})
                severity = deserialized_item.get('severity', 'UNKNOWN')
                source = deserialized_item.get('source', 'unknown')
                event_type = deserialized_item.get('event_type', 'Unknown')
                
                # Calculate priority score using the same logic as alert-triage
                priority_score = calculate_priority_score(threat_score, source, event_type)

                threat = {
                    'alert_id': deserialized_item.get('alert_id', 'N/A'),
                    'timestamp': deserialized_item.get('timestamp', 'N/A'),
                    'severity': severity,
                    'priority_score': priority_score,
                    'threat_score': threat_score * 100,
                    'event_type': event_type,
                    'source': source,
                    'raw_event': raw_event,
                    'ml_prediction': {
                        'prediction_label': prediction_label,
                        'model_version': model_version,
                        'evaluated_at': evaluated_at,
                        'threat_score': threat_score * 100
                    }
                }
                if severity not in threats_by_severity:
                    threats_by_severity['UNKNOWN'].append(threat)
                else:
                    threats_by_severity[severity].append(threat)

            items_scanned += len(result.get('Items', []))
            last_evaluated_key = result.get('LastEvaluatedKey')
            if not last_evaluated_key:
                break

        # For each severity, sort by priority_score and take top 50
        # Also reduce max items to scan since we only need 50 per severity
        top_threats = {}
        total_count = 0
        for severity, threat_list in threats_by_severity.items():
            sorted_threats = sorted(threat_list, key=lambda x: x['priority_score'], reverse=True)
            top_threats[severity] = sorted_threats[:50]
            total_count += len(top_threats[severity])

        return response(200, {
            'success': True,
            'count': total_count,
            'threats': top_threats
        })
    except Exception as e:
        return response(500, {
            'success': False,
            'error': str(e)
        })

def get_stats():
    """Get threat statistics - with limit to prevent timeout"""
    try:
        items = []
        last_evaluated_key = None
        max_items_to_scan = 500  # Limit to prevent timeout
        
        # Paginate through results with limit
        items_scanned = 0
        while items_scanned < max_items_to_scan:
            scan_kwargs = {
                'TableName': TABLE_NAME,
                'Limit': min(100, max_items_to_scan - items_scanned)
            }
            if last_evaluated_key:
                scan_kwargs['ExclusiveStartKey'] = last_evaluated_key
            
            result = dynamodb.scan(**scan_kwargs)
            items.extend(result.get('Items', []))
            
            items_scanned += len(result.get('Items', []))
            last_evaluated_key = result.get('LastEvaluatedKey')
            if not last_evaluated_key:
                break
        
        total = len(items)
        by_severity = {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0, 'UNKNOWN': 0}
        high_threat = 0
        auto_remediated = 0
        
        for item in items:
            deserialized_item = {k: deserialize_dynamodb_item(v) for k, v in item.items()}
            severity = deserialized_item.get('severity', 'UNKNOWN')
            by_severity[severity] = by_severity.get(severity, 0) + 1
            
            # Count high threat scores
            ml_prediction = deserialized_item.get('ml_prediction', {})
            threat_score = float(ml_prediction.get('threat_score', 0))
            if threat_score > 0.7:
                high_threat += 1
            
            # Count auto-remediated (you can adjust this logic based on your data)
            if deserialized_item.get('remediation_status') == 'auto_remediated':
                auto_remediated += 1
        
        return response(200, {
            'success': True,
            'stats': {
                'total_threats': total,
                'by_severity': by_severity,
                'high_threat_score': high_threat,
                'auto_remediated': auto_remediated
            }
        })
    
    except Exception as e:
        return response(500, {
            'success': False,
            'error': str(e)
        })

def handler(event, context):
    """Lambda handler - routes requests to appropriate function"""
    
    # API Gateway HTTP API uses different event structure
    # Get path from rawPath for HTTP API v2.0
    path = event.get('rawPath', event.get('path', '/'))
    method = event.get('requestContext', {}).get('http', {}).get('method', event.get('httpMethod', 'GET'))
    
    # Handle OPTIONS for CORS preflight
    if method == 'OPTIONS':
        return response(200, {'message': 'OK'})
    
    # Route based on path
    if '/threats' in path:
        return get_threats()
    elif '/stats' in path:
        return get_stats()
    else:
        return response(404, {
            'success': False,
            'error': f'Path not found: {path}',
            'event_keys': list(event.keys())  # Debug info
        })
